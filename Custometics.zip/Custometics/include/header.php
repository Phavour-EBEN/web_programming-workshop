<!--use all.css -->
<div class="header">
        <div class="logo">
            <img src="" alt="">
            <h2>Cosmetics</h2>
        </div>
        <input type="checkbox" id="toggle-menu">
        <label for="toggle-menu">
            <svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512"><line x1="88" y1="152" x2="424" y2="152" style="fill:none;stroke:#000;stroke-linecap:round;stroke-miterlimit:10;stroke-width:48px"/><line x1="88" y1="256" x2="424" y2="256" style="fill:none;stroke:#000;stroke-linecap:round;stroke-miterlimit:10;stroke-width:48px"/><line x1="88" y1="360" x2="424" y2="360" style="fill:none;stroke:#000;stroke-linecap:round;stroke-miterlimit:10;stroke-width:48px"/></svg>
        </label>
        <div class="nav">
            <ul class="menu">
                <li>
                    <a href="#">Home</a>
                </li>
                <li>
                    <a href="#">products</a>
                </li>
                <li>
                    <a href="#">about us</a>
                </li>
                <li>
                    <a href="#">contact us</a>
                </li>
                <li>
                    <a href="#">location</a>
                </li>
            </ul>
        </div>
    </div>
/*
let height = 188;
let anotherheight =height;
let weight = 70;
console.log(height);
console.log(anotherheight)
console.log(weight);
"use strict"
let steps = 100;
console.log(steps);
steps = 120;
console.log(steps);
steps = steps+200;
console.log(steps)
//Scope(block)
let counter;
console.log(counter);
{
    counter = 5;
    console.log(counter);
}
counter = counter + 2;
console.log(counter)

let num = 200;
{
    let no = 300;
    console.log(num);
    console.log(no);
    no =no+num;
    console.log(no);
    {
        let info = "tall"
        console.log(info);
        console.log(num);
    }

}

var globalgreeting = "good";

function testfunction(){
    var localgreeting = "morning";
    consloe.log("function: ");
    console.log(globalgreeting);
    console.log(localgreeting);

}

testfunction();
console.log("main function: ");
console.log(globalgreeting);
console.log(localgreeting);
*/
var a = 20
var b = 10
console.log(a+b)
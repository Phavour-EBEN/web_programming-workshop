/* function yes(name,age){
    if (age <18){
         return name+"!";
     } else {
     return name;

 }
 }
 alert(yes("joy",12));
 
ARRAYS AND LOOPS
//var my_name = ["jon","Tom","James","banan"]
//alert(my_name)

var mylist = ["Banan","apple","orange","yam","beans"];
mylist.forEach(function(value,index){
   // console.log(values,index)
    alert("I have the fellowing items,"+value+" in my bag");
});


var x = 0;
//while(x < 10) {
    //console.log("Let's keep adding", x);
   // x +=1;
    
}*/
var my_name = ["jon","Tom","James","banan"];

for(var j=1;j < my_name.length;j++){
    alert("This is my frind "+my_name[j]);
}

console.log("hello world")
var myvar = "global";
function checkscope(){
    var myvar = "local";
    document.write(myvar);
    console.log(checkscope);
}
console.log(myvar);
checkscope()
